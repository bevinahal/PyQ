Enlightenment Research, LLC [pyq@enlnt.com](mailto:pyq@enlnt.com)
