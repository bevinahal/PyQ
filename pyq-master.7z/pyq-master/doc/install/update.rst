Keeping PyQ up-to-date
----------------------

You can upgrade PyQ to the latest version by running:

::

    pip install -i https://pyq.enlnt.com --no-binary pyq -U pyq
