.. _license:

###################
PyQ General License
###################

PyQ is distributed as open source software and is free for the users of the 32bit
edition of kdb+ under the terms of the :ref:`free 32-bit license<32-bit-license>`.

For more information, see the following sections.

.. toctree::
   :maxdepth: 2

   copyright
   license
