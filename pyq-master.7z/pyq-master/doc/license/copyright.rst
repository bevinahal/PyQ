*********
Copyright
*********

Copyright © 2003-2013 Alexander Belopolsky.

Copyright © 2013-2017 Enlightenment Research, LLC.

All rights reserved.
